<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Edit address</name>
   <tag></tag>
   <elementGuidId>f849b2c5-5ab5-41e0-a04b-f633b7fc1ddc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='address-list']/div/div/div/fieldset/div/span/div/label/span/span[3]/span/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.a-declarative > a.a-link-normal</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a5daa764-adf5-473c-b622-b3d5b3298232</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Edit address 

Maries, 9/4, karivalam, TIRUNELVELI, TAMIL NADU, 627753 India

</value>
      <webElementGuid>75210aa6-c5a1-4b7a-8051-16a2f5318be5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-link-normal</value>
      <webElementGuid>22ebf29a-1f05-4e9f-8b6c-389d65c7bd53</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/gp/buy/addressselect/handlers/popover/edit.html/ref=chk_addr_edit_pri_1?ie=UTF8&amp;abBusinessGroupId=&amp;action=edit&amp;addressID=RJJMT7OKVVWHTDDWGRA4G12VFYMTISYIXA2OXIYSITMYFV2PXTQ2EIA2OXPQO2O2&amp;enableDeliveryPreferences=1&amp;fromAnywhere=0&amp;numberOfDistinctItems=4&amp;purchaseId=106-4673086-8897004&amp;requestToken=&amp;skipHeader=0</value>
      <webElementGuid>c6d9c4ac-7ca6-40e7-b2c4-cd963890a2ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Edit address</value>
      <webElementGuid>f46e933f-e27b-4087-a718-184004c5de10</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;address-list&quot;)/div[@class=&quot;a-box-group a-spacing-small&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner&quot;]/fieldset[1]/div[@class=&quot;a-row address-row list-address-selected&quot;]/span[@class=&quot;a-declarative&quot;]/div[@class=&quot;a-radio&quot;]/label[1]/span[@class=&quot;a-label a-radio-label&quot;]/span[@class=&quot;address-edit-link&quot;]/span[@class=&quot;a-declarative&quot;]/a[@class=&quot;a-link-normal&quot;]</value>
      <webElementGuid>8b78021e-f1ea-4565-874f-8aca02ef2242</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='address-list']/div/div/div/fieldset/div/span/div/label/span/span[3]/span/a</value>
      <webElementGuid>994ed0d1-7e2f-460e-bb3c-81de06552026</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Edit address')]</value>
      <webElementGuid>ba0dc367-4a21-4298-b68b-ed5c5fe3cfee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Maries'])[1]/following::a[1]</value>
      <webElementGuid>95069596-2172-475b-89ae-b86af4859cb0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shipping to more than one address?'])[1]/following::a[1]</value>
      <webElementGuid>00f6b617-d960-45e7-a42d-6b3b39de7f68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add a new address'])[2]/preceding::a[2]</value>
      <webElementGuid>c9bd63b5-804c-40a0-b811-ff54f5066d03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save time. Autofill your current location.'])[1]/preceding::a[2]</value>
      <webElementGuid>d8d2cc79-1bf8-45dc-8d23-72a01c0f5b28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Edit address']/parent::*</value>
      <webElementGuid>0d2ac023-9381-43c8-ac65-e14bbd25f29a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/gp/buy/addressselect/handlers/popover/edit.html/ref=chk_addr_edit_pri_1?ie=UTF8&amp;abBusinessGroupId=&amp;action=edit&amp;addressID=RJJMT7OKVVWHTDDWGRA4G12VFYMTISYIXA2OXIYSITMYFV2PXTQ2EIA2OXPQO2O2&amp;enableDeliveryPreferences=1&amp;fromAnywhere=0&amp;numberOfDistinctItems=4&amp;purchaseId=106-4673086-8897004&amp;requestToken=&amp;skipHeader=0')]</value>
      <webElementGuid>e80802e5-d211-4843-b5c4-9a6191d0b3d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[3]/span/a</value>
      <webElementGuid>4f83b24e-fb86-4ec9-a29b-88fa876fe880</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/gp/buy/addressselect/handlers/popover/edit.html/ref=chk_addr_edit_pri_1?ie=UTF8&amp;abBusinessGroupId=&amp;action=edit&amp;addressID=RJJMT7OKVVWHTDDWGRA4G12VFYMTISYIXA2OXIYSITMYFV2PXTQ2EIA2OXPQO2O2&amp;enableDeliveryPreferences=1&amp;fromAnywhere=0&amp;numberOfDistinctItems=4&amp;purchaseId=106-4673086-8897004&amp;requestToken=&amp;skipHeader=0' and (text() = 'Edit address' or . = 'Edit address')]</value>
      <webElementGuid>45601656-167d-442c-b180-d7d34326b746</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
