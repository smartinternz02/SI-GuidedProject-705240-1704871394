<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Cart</name>
   <tag></tag>
   <elementGuidId>681f720a-9547-4116-aa21-16f68f814136</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='nav-cart-text-container']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#nav-cart-text-container</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>45f4db80-dd83-47c8-885f-7dfe05e1d406</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>nav-cart-text-container</value>
      <webElementGuid>d7408bec-f8b5-4c65-8f30-ab260005dbf7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> nav-progressive-attribute</value>
      <webElementGuid>a088a9c3-d53d-4280-b117-911c3c420b76</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      
        
      
      
        Cart
        
      
    </value>
      <webElementGuid>f41ddfa3-faa9-4e71-869c-81f28541a844</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-cart-text-container&quot;)</value>
      <webElementGuid>adb9c929-72fe-4e4c-93e3-41049a6430c1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='nav-cart-text-container']</value>
      <webElementGuid>65425a2d-9d8d-430f-bb77-b0fda0bc4c34</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='nav-cart']/div[2]</value>
      <webElementGuid>7e9bb524-b4df-4730-8914-85294e944e84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='&amp; Orders'])[1]/following::div[2]</value>
      <webElementGuid>b6c10ee6-7476-4a53-8c7e-2bd67d5587c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Returns'])[1]/following::div[2]</value>
      <webElementGuid>4d169ab2-f106-4626-9ef0-d2f41c986fe4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Your Lists'])[1]/preceding::div[19]</value>
      <webElementGuid>2ac9eb78-080b-4127-a715-d51855e791bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create a List'])[1]/preceding::div[21]</value>
      <webElementGuid>43dec1af-0e8f-4219-8639-7f5bb1715884</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[5]/div[2]</value>
      <webElementGuid>902fe196-a5e3-475e-a999-6fdbab7ad0c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'nav-cart-text-container' and (text() = '
      
        
      
      
        Cart
        
      
    ' or . = '
      
        
      
      
        Cart
        
      
    ')]</value>
      <webElementGuid>5673e8f7-5386-4483-ad06-f221ba3ae5ff</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
