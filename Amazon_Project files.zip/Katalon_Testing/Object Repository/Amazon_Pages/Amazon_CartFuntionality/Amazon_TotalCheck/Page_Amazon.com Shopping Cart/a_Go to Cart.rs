<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Go to Cart</name>
   <tag></tag>
   <elementGuidId>c419d7b2-4fc3-4117-b959-09cb3b2cc68f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='ewc-compact-actions-container']/div/div[2]/span/span/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.a-button-text</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>90ce264e-727a-4b8f-8ce1-161d1945e872</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/cart?ref_=ewc_gtc</value>
      <webElementGuid>525c7ed9-5f75-4eef-8844-4985b8f84fea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-button-text</value>
      <webElementGuid>55a5a6fb-5a5c-46ba-86ef-6e6585bfe5fa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        Go to Cart
    </value>
      <webElementGuid>8813bd57-b43f-4423-bc5d-19172446c1dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ewc-compact-actions-container&quot;)/div[@class=&quot;a-row ewc-compact-actions ewc-compact-actions--selected&quot;]/div[@class=&quot;a-row a-spacing-base a-spacing-top-small ewc-go-to-cart celwidget&quot;]/span[@class=&quot;a-button a-button-span11 a-button-base a-button-small a-button-focus&quot;]/span[@class=&quot;a-button-inner&quot;]/a[@class=&quot;a-button-text&quot;]</value>
      <webElementGuid>d45f2ce6-8509-474d-8198-fdf06fb5ac19</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='ewc-compact-actions-container']/div/div[2]/span/span/a</value>
      <webElementGuid>b9bc0dfe-8a1b-46d1-9585-efbc76d0fc95</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Go to Cart')]</value>
      <webElementGuid>0514d58a-bcd4-485b-a922-7029ba2cb691</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INR 2,326.76'])[1]/following::a[1]</value>
      <webElementGuid>f18f8cfb-59e9-43d2-a1ac-a309647e2270</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Subtotal'])[1]/following::a[1]</value>
      <webElementGuid>fc275e87-339f-49eb-91eb-7eb3e45f60c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INR 496.34'])[1]/preceding::a[2]</value>
      <webElementGuid>e838682d-27b6-4e84-ba2c-7cc8cec0460e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Go to Cart']/parent::*</value>
      <webElementGuid>24929a2d-ad1b-4c5d-84dd-68e254f65ecb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/cart?ref_=ewc_gtc')]</value>
      <webElementGuid>18c4afed-3257-4a59-810a-606d57f0a5df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/span/a</value>
      <webElementGuid>dcfcfe4b-6c37-433e-a60d-5d3b1527821a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/cart?ref_=ewc_gtc' and (text() = '
        Go to Cart
    ' or . = '
        Go to Cart
    ')]</value>
      <webElementGuid>f6ea773c-bdc2-4f81-9ee8-410322acaa17</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
