<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_4 Stars  Up</name>
   <tag></tag>
   <elementGuidId>8e0c803e-f363-4294-a8c2-43fcacce6d6c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='p_72/2491149011']/span/a/section/i</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>i.a-icon.a-icon-star-medium.a-star-medium-4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
      <webElementGuid>fd9cad8f-94b4-40af-bccc-aab86c0cd4b4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-icon a-icon-star-medium a-star-medium-4</value>
      <webElementGuid>d6168a1f-7117-4b1e-ac92-582ec61152ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>4 Stars &amp; Up</value>
      <webElementGuid>f92f9bb1-dc91-4f68-8e33-f3a71b8882fc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;p_72/2491149011&quot;)/span[@class=&quot;a-list-item&quot;]/a[@class=&quot;a-link-normal s-navigation-item&quot;]/section[1]/i[@class=&quot;a-icon a-icon-star-medium a-star-medium-4&quot;]</value>
      <webElementGuid>820ba56d-ca68-4bb1-a9ff-1e975305fce7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='p_72/2491149011']/span/a/section/i</value>
      <webElementGuid>a316407c-fbe0-4e81-b955-b807b870863c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customer Reviews'])[1]/following::i[1]</value>
      <webElementGuid>66742d24-9c00-464a-a7b7-aba70fb5f2ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cell Phones'])[1]/following::i[1]</value>
      <webElementGuid>ca073b2c-8902-405c-8b8c-e958e0f03b86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='&amp; Up'])[1]/preceding::i[1]</value>
      <webElementGuid>dc4cd494-e535-415c-8def-06bfe10488f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='&amp; Up'])[2]/preceding::i[2]</value>
      <webElementGuid>b0c082b4-5755-4624-af48-bab7dd375e3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/i</value>
      <webElementGuid>2c599a89-c9d9-4bdf-9c55-77c23dd89c52</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//i[(text() = '4 Stars &amp; Up' or . = '4 Stars &amp; Up')]</value>
      <webElementGuid>809687b7-dafb-43f8-846e-13bb5365a66d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
