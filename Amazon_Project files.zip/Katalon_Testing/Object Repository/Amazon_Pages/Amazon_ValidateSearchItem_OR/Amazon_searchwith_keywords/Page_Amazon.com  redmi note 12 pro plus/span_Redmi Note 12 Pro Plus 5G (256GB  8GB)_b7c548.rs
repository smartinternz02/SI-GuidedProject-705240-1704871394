<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Redmi Note 12 Pro Plus 5G (256GB  8GB)_b7c548</name>
   <tag></tag>
   <elementGuidId>7fba2846-639b-4e38-8b1a-fa016c448ec3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='search']/div/div/div/span/div/div[3]/div/div/span/div/div/div/div[2]/div/div/div/h2/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>e1928edd-a01a-4452-8740-fef9d4eb500f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-size-medium a-color-base a-text-normal</value>
      <webElementGuid>880c059f-a65b-4660-b56d-e633116119b6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Redmi Note 12 Pro+ Plus 5G (256GB + 8GB) Factory Unlocked 6.67&quot; 200MP Triple Camera (Only 4G Tmobile/Tello/Mint USA Market) + Extra (w/Fast Car Charger Bundle) (Midnight Black (Global))</value>
      <webElementGuid>d43e3832-2f74-46e3-bf9c-99a1a9a63aad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;search&quot;)/div[@class=&quot;s-desktop-width-max s-desktop-content s-wide-grid-style-t1 s-opposite-dir s-wide-grid-style sg-row&quot;]/div[@class=&quot;sg-col-20-of-24 s-matching-dir sg-col-16-of-20 sg-col sg-col-8-of-12 sg-col-12-of-16&quot;]/div[@class=&quot;sg-col-inner&quot;]/span[@class=&quot;rush-component s-latency-cf-section&quot;]/div[@class=&quot;s-main-slot s-result-list s-search-results sg-row&quot;]/div[@class=&quot;sg-col-20-of-24 s-result-item s-asin sg-col-0-of-12 sg-col-16-of-20 sg-col s-widget-spacing-small sg-col-12-of-16&quot;]/div[@class=&quot;sg-col-inner&quot;]/div[@class=&quot;s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_2&quot;]/span[@class=&quot;a-declarative&quot;]/div[@class=&quot;puis-card-container s-card-container s-overflow-hidden aok-relative puis-include-content-margin puis puis-v3t2vism9ma9te2v0r14oy30p6q s-latency-cf-section puis-card-border&quot;]/div[@class=&quot;a-section&quot;]/div[@class=&quot;puisg-row&quot;]/div[@class=&quot;puisg-col puisg-col-4-of-12 puisg-col-8-of-16 puisg-col-12-of-20 puisg-col-12-of-24 puis-list-col-right&quot;]/div[@class=&quot;puisg-col-inner&quot;]/div[@class=&quot;a-section a-spacing-small a-spacing-top-small&quot;]/div[@class=&quot;a-section a-spacing-none puis-padding-right-small s-title-instructions-style&quot;]/h2[@class=&quot;a-size-mini a-spacing-none a-color-base s-line-clamp-2&quot;]/a[@class=&quot;a-link-normal s-underline-text s-underline-link-text s-link-style a-text-normal&quot;]/span[@class=&quot;a-size-medium a-color-base a-text-normal&quot;]</value>
      <webElementGuid>c5048c53-010c-47dc-96b7-9bbcb4d48baf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='search']/div/div/div/span/div/div[3]/div/div/span/div/div/div/div[2]/div/div/div/h2/a/span</value>
      <webElementGuid>6d5d099d-3850-438a-ba01-9ee92329d2a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Xiaomi'])[1]/following::span[1]</value>
      <webElementGuid>4369624c-e8f3-4af6-ae78-03c7328eef9b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='-'])[1]/following::span[5]</value>
      <webElementGuid>cb244e70-f881-425f-967d-b23c098be3b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INR 30,617.51'])[1]/preceding::span[8]</value>
      <webElementGuid>76a24357-ec0a-42ab-a030-7d2605e65cc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INR'])[2]/preceding::span[9]</value>
      <webElementGuid>d4650379-2f17-4e0b-a5c0-ce0e46ad027a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Redmi Note 12 Pro+ Plus 5G (256GB + 8GB) Factory Unlocked 6.67&quot; 200MP Triple Camera (Only 4G Tmobile/Tello/Mint USA Market) + Extra (w/Fast Car Charger Bundle) (Midnight Black (Global))']/parent::*</value>
      <webElementGuid>97449474-a88a-4863-ae62-2a5d31dbcedd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/span/div/div/div/div[2]/div/div/div/h2/a/span</value>
      <webElementGuid>d5f035a0-30e7-4dee-867b-fc2da5151af1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Redmi Note 12 Pro+ Plus 5G (256GB + 8GB) Factory Unlocked 6.67&quot; 200MP Triple Camera (Only 4G Tmobile/Tello/Mint USA Market) + Extra (w/Fast Car Charger Bundle) (Midnight Black (Global))' or . = 'Redmi Note 12 Pro+ Plus 5G (256GB + 8GB) Factory Unlocked 6.67&quot; 200MP Triple Camera (Only 4G Tmobile/Tello/Mint USA Market) + Extra (w/Fast Car Charger Bundle) (Midnight Black (Global))')]</value>
      <webElementGuid>f7f672e5-78ce-4efa-abe8-43d25bfacc40</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
