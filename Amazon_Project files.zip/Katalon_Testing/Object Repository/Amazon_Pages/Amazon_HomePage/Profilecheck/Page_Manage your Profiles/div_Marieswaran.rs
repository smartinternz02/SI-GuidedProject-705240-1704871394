<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Marieswaran</name>
   <tag></tag>
   <elementGuidId>8b2df802-9ce4-4655-9ee4-44ed2c07cb50</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[@id='profile-pick-actor-button-0']/a/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.a-column.a-span11.a-spacing-base.aok-break-word</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>02a6546e-1056-4460-af33-f65af4ee9f88</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-column a-span11 a-spacing-base aok-break-word</value>
      <webElementGuid>e4cd8b7e-8004-450e-a120-3bcabf30d2c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
        
            
            
                
                    Marieswaran
                
            
        
    </value>
      <webElementGuid>c4285489-53c2-4f98-a689-f279433d684c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;profile-pick-actor-button-0&quot;)/a[@class=&quot;a-color-base a-link-normal linkStylingHover&quot;]/div[@class=&quot;a-row a-spacing-top-small a-grid-vertical-align a-grid-center a-ws-row&quot;]/div[@class=&quot;a-column a-span11 a-spacing-base aok-break-word&quot;]</value>
      <webElementGuid>75f5c774-f7f1-4e56-8379-215686d62427</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//span[@id='profile-pick-actor-button-0']/a/div/div</value>
      <webElementGuid>c51f947b-d13e-4deb-a5e1-81d3d5d6384b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Manage your Profiles'])[2]/following::div[4]</value>
      <webElementGuid>7a4f55bb-b090-439d-b642-73a4e13fa2ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Disability Customer Support'])[1]/following::div[20]</value>
      <webElementGuid>a3f0e57b-e211-49bb-b26f-ea355a09d40a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='posts, reviews and other public content'])[1]/preceding::div[2]</value>
      <webElementGuid>f3254160-0302-4d55-b534-1d16c5bb27ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/div/div</value>
      <webElementGuid>8405e607-f616-48be-b1a9-53e0a077baff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        
        
            
            
                
                    Marieswaran
                
            
        
    ' or . = '
        
        
            
            
                
                    Marieswaran
                
            
        
    ')]</value>
      <webElementGuid>d0c454d9-8163-4f2f-b418-3dc076fa5a37</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
