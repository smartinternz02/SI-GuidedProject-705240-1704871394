<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_window.navmet.tmpnew Date()Todays Deals_089c31</name>
   <tag></tag>
   <elementGuidId>ccb47eb5-d8c2-467e-8101-d3a17cfea57c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='nav-xshop']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#nav-xshop</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>9f4fa94f-b5a2-4186-a128-14f550434307</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>nav-xshop</value>
      <webElementGuid>45a1b111-1a9f-4237-b2e3-76cfa39386d2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-progressive-content</value>
      <webElementGuid>b42fc4a2-647b-42fc-83a2-a6bbbf8cb703</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            window.navmet.tmp=+new Date();
Today's Deals

Registry

Customer Service

Gift Cards

Sell

Disability Customer Support
window.navmet.push({key:'CrossShop',end:+new Date(),begin:window.navmet.tmp});
          </value>
      <webElementGuid>e5abcdec-3cc9-43d6-9cba-00672e01879e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-xshop&quot;)</value>
      <webElementGuid>da1d7701-74f2-433c-9a73-e19c67de736c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='nav-xshop']</value>
      <webElementGuid>b09201f8-246b-48df-93c4-a5079cfa7ee0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-xshop-container']/div</value>
      <webElementGuid>5a82a8b8-dbc2-4753-bac2-db227d46dee6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='India'])[2]/following::div[5]</value>
      <webElementGuid>059327da-971d-4cee-be7f-f87c8220389d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='International Shopping Transition Alert'])[1]/following::div[10]</value>
      <webElementGuid>11a715f4-852c-4457-b0c6-2a5e76541aa8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/div[2]/div</value>
      <webElementGuid>7af70bd8-991a-4c17-8c7e-c8153051739c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'nav-xshop' and (text() = concat(&quot;
            window.navmet.tmp=+new Date();
Today&quot; , &quot;'&quot; , &quot;s Deals

Registry

Customer Service

Gift Cards

Sell

Disability Customer Support
window.navmet.push({key:&quot; , &quot;'&quot; , &quot;CrossShop&quot; , &quot;'&quot; , &quot;,end:+new Date(),begin:window.navmet.tmp});
          &quot;) or . = concat(&quot;
            window.navmet.tmp=+new Date();
Today&quot; , &quot;'&quot; , &quot;s Deals

Registry

Customer Service

Gift Cards

Sell

Disability Customer Support
window.navmet.push({key:&quot; , &quot;'&quot; , &quot;CrossShop&quot; , &quot;'&quot; , &quot;,end:+new Date(),begin:window.navmet.tmp});
          &quot;))]</value>
      <webElementGuid>d85d9015-dfae-4b65-a87f-1a9c5472e1f6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
