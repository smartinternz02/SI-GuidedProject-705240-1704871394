<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Edit address</name>
   <tag></tag>
   <elementGuidId>6e7fd8a2-675c-4190-88cb-f3a5ad9080d7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='address-list']/div/div/div/fieldset/div/span/div/label/span/span[3]/span/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.a-declarative > a.a-link-normal</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>18f37842-47af-4ac1-b50b-c06f49e7dfe9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Edit address 

Maries, 9/4, karivalam, TIRUNELVELI, TAMIL NADU, 627753 India

</value>
      <webElementGuid>7b8116a2-ca8a-42c8-a562-eaada9caab0a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-link-normal</value>
      <webElementGuid>719fd7fb-f811-4c28-9064-745d7ffa8889</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/gp/buy/addressselect/handlers/popover/edit.html/ref=chk_addr_edit_pri_1?ie=UTF8&amp;abBusinessGroupId=&amp;action=edit&amp;addressID=RJJMT7OKVVWHTDDWGRA4G12VFYMTISYIXA2OXIYSITMYFV2PXTQ2EIA2OXPQO2O2&amp;enableDeliveryPreferences=1&amp;fromAnywhere=0&amp;numberOfDistinctItems=1&amp;purchaseId=106-1219207-5122619&amp;requestToken=&amp;skipHeader=0</value>
      <webElementGuid>1f441f60-1d06-4775-b302-5b66f7269a39</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Edit address</value>
      <webElementGuid>0970602e-981b-4f8d-9fd2-8724d788fe23</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;address-list&quot;)/div[@class=&quot;a-box-group a-spacing-small&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner&quot;]/fieldset[1]/div[@class=&quot;a-row address-row list-address-selected&quot;]/span[@class=&quot;a-declarative&quot;]/div[@class=&quot;a-radio&quot;]/label[1]/span[@class=&quot;a-label a-radio-label&quot;]/span[@class=&quot;address-edit-link&quot;]/span[@class=&quot;a-declarative&quot;]/a[@class=&quot;a-link-normal&quot;]</value>
      <webElementGuid>22eb390e-c80e-4eb7-8b86-a904624a02c9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='address-list']/div/div/div/fieldset/div/span/div/label/span/span[3]/span/a</value>
      <webElementGuid>26519cc4-c51b-4fd3-89c1-8180e0736eca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Edit address')]</value>
      <webElementGuid>12d7f8a1-1108-4d89-b73f-d46aee949f24</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Maries'])[1]/following::a[1]</value>
      <webElementGuid>4520c0e3-2242-4da1-8028-1c89cb202df2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Your addresses'])[1]/following::a[1]</value>
      <webElementGuid>8641846a-fb8b-48a8-b6e1-9402de0acfdd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add a new address'])[2]/preceding::a[2]</value>
      <webElementGuid>07bb4901-cc63-443b-a4c1-97686a98bd11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save time. Autofill your current location.'])[1]/preceding::a[2]</value>
      <webElementGuid>07b6a98c-ef14-49ca-8d3d-505e5e440bdc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Edit address']/parent::*</value>
      <webElementGuid>a6d96e6f-c44d-460e-928d-e1af3ef24ff0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/gp/buy/addressselect/handlers/popover/edit.html/ref=chk_addr_edit_pri_1?ie=UTF8&amp;abBusinessGroupId=&amp;action=edit&amp;addressID=RJJMT7OKVVWHTDDWGRA4G12VFYMTISYIXA2OXIYSITMYFV2PXTQ2EIA2OXPQO2O2&amp;enableDeliveryPreferences=1&amp;fromAnywhere=0&amp;numberOfDistinctItems=1&amp;purchaseId=106-1219207-5122619&amp;requestToken=&amp;skipHeader=0')]</value>
      <webElementGuid>811d8573-e8d1-4f86-981b-04090f19e44e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[3]/span/a</value>
      <webElementGuid>3c011d46-937a-47aa-ad14-5e8c24ce96f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/gp/buy/addressselect/handlers/popover/edit.html/ref=chk_addr_edit_pri_1?ie=UTF8&amp;abBusinessGroupId=&amp;action=edit&amp;addressID=RJJMT7OKVVWHTDDWGRA4G12VFYMTISYIXA2OXIYSITMYFV2PXTQ2EIA2OXPQO2O2&amp;enableDeliveryPreferences=1&amp;fromAnywhere=0&amp;numberOfDistinctItems=1&amp;purchaseId=106-1219207-5122619&amp;requestToken=&amp;skipHeader=0' and (text() = 'Edit address' or . = 'Edit address')]</value>
      <webElementGuid>22cd7b69-56f9-43b5-9d61-6c0d24079897</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
