<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Edit address</name>
   <tag></tag>
   <elementGuidId>e2fb12c1-c03e-477f-a1cb-83a70d71326c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='address-list']/div/div/div/fieldset/div/span/div/label/span/span[3]/span/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.a-declarative > a.a-link-normal</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>659a2cc8-0315-4561-8e43-7baf63fe5755</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Edit address 

Marieswarn, 9/4, karivalam, SANKARANKOIL, TAMIL NADU, 627753 India

</value>
      <webElementGuid>b44e28c6-e1bd-4452-8434-112810ffbb95</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-link-normal</value>
      <webElementGuid>756ceab0-4e85-4b9b-884e-0255b4f47800</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/gp/buy/addressselect/handlers/popover/edit.html/ref=chk_addr_edit_pri_1?ie=UTF8&amp;abBusinessGroupId=&amp;action=edit&amp;addressID=RJJMT7OKVVWHTDDWGRA4G12VFYMTISYIXA2OXIYSITMYFV2PXTQ2EQA2OXPQO2O2&amp;enableDeliveryPreferences=1&amp;fromAnywhere=0&amp;numberOfDistinctItems=1&amp;purchaseId=106-7321319-7772243&amp;requestToken=&amp;skipHeader=0</value>
      <webElementGuid>421c6afe-a052-4eb7-974e-440c01b68b5d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Edit address</value>
      <webElementGuid>151fb177-12c7-434c-85b2-49b80952b5fa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;address-list&quot;)/div[@class=&quot;a-box-group a-spacing-small&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner&quot;]/fieldset[1]/div[@class=&quot;a-row address-row list-address-selected&quot;]/span[@class=&quot;a-declarative&quot;]/div[@class=&quot;a-radio&quot;]/label[1]/span[@class=&quot;a-label a-radio-label&quot;]/span[@class=&quot;address-edit-link&quot;]/span[@class=&quot;a-declarative&quot;]/a[@class=&quot;a-link-normal&quot;]</value>
      <webElementGuid>b42b17c0-ab3b-4dc3-bd6f-359685db55e1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='address-list']/div/div/div/fieldset/div/span/div/label/span/span[3]/span/a</value>
      <webElementGuid>05d4e821-bb30-4908-a4ae-f573b2531a93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Edit address')]</value>
      <webElementGuid>43530738-010b-4498-a72e-ae636434b911</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Marieswarn'])[1]/following::a[1]</value>
      <webElementGuid>85f0dd07-562b-4b5e-b341-b09fcfda2b54</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Your addresses'])[1]/following::a[1]</value>
      <webElementGuid>29833e32-4b6b-4cde-a349-6deca807af3c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add a new address'])[2]/preceding::a[2]</value>
      <webElementGuid>955cb806-bc87-4d96-a994-99c8d0028ae1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save time. Autofill your current location.'])[1]/preceding::a[2]</value>
      <webElementGuid>8cd28947-c5ce-469e-940c-0426eb370aa4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Edit address']/parent::*</value>
      <webElementGuid>a4744f57-994b-4a27-9bad-cbeb7538287c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/gp/buy/addressselect/handlers/popover/edit.html/ref=chk_addr_edit_pri_1?ie=UTF8&amp;abBusinessGroupId=&amp;action=edit&amp;addressID=RJJMT7OKVVWHTDDWGRA4G12VFYMTISYIXA2OXIYSITMYFV2PXTQ2EQA2OXPQO2O2&amp;enableDeliveryPreferences=1&amp;fromAnywhere=0&amp;numberOfDistinctItems=1&amp;purchaseId=106-7321319-7772243&amp;requestToken=&amp;skipHeader=0')]</value>
      <webElementGuid>b6fd540d-e3f6-4e95-be45-cb40cdcd042b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[3]/span/a</value>
      <webElementGuid>8bde97e4-017b-4d4a-a639-c02e9ccd7af6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/gp/buy/addressselect/handlers/popover/edit.html/ref=chk_addr_edit_pri_1?ie=UTF8&amp;abBusinessGroupId=&amp;action=edit&amp;addressID=RJJMT7OKVVWHTDDWGRA4G12VFYMTISYIXA2OXIYSITMYFV2PXTQ2EQA2OXPQO2O2&amp;enableDeliveryPreferences=1&amp;fromAnywhere=0&amp;numberOfDistinctItems=1&amp;purchaseId=106-7321319-7772243&amp;requestToken=&amp;skipHeader=0' and (text() = 'Edit address' or . = 'Edit address')]</value>
      <webElementGuid>39a5b051-d7f0-4e79-8dbc-1b04b031dc98</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
