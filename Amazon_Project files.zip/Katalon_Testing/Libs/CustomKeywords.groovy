
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String



def static "com.qa.test.CustomFunctions.printworld"() {
    (new com.qa.test.CustomFunctions()).printworld()
}


def static "com.qa.test.CustomFunctions.CheckDropDownListElementExist"(
    	TestObject object	
     , 	String labelText	) {
    (new com.qa.test.CustomFunctions()).CheckDropDownListElementExist(
        	object
         , 	labelText)
}


def static "com.qa.test.CustomFunctions.CheckSigninElementExist"(
    	TestObject object	
     , 	String option	) {
    (new com.qa.test.CustomFunctions()).CheckSigninElementExist(
        	object
         , 	option)
}
